document.addEventListener('DOMContentLoaded', function () {
    console.log('Document loaded, initializing...');
    checkAuthentication();
});

async function checkAuthentication() {
    try {
        const response = await fetch('/admin/tables', {
            headers: {
                'Authorization': `Bearer ${getCookie('access_token')}`
            }
        });
        if (!response.ok) {
            throw new Error('Not authenticated');
        }
        initializeAdmin();
    } catch (error) {
        window.location.href = '/login';
    }
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}

async function initializeAdmin() {
    console.log('Fetching tables...');
    const response = await fetch('/admin/tables', {
        headers: {
            'Authorization': `Bearer ${getCookie('access_token')}`
        }
    });
    const tables = await response.json();
    console.log('Tables available:', tables);
    populateTableList(tables);
}

function populateTableList(tables) {
    const tableList = document.getElementById('table-list');
    tableList.innerHTML = '';
    tables.forEach(table => {
        const listItem = document.createElement('li');
        listItem.classList.add('nav-item');
        const link = document.createElement('a');
        link.classList.add('nav-link');
        link.href = `#${table}`;
        link.textContent = table;
        link.addEventListener('click', () => loadTable(table));
        listItem.appendChild(link);
        tableList.appendChild(listItem);
    });
}

async function loadTable(table) {
    console.log(`Loading table: ${table}`);
    currentPage = 0;
    pageSize = 25;
    currentSortColumn = 'id';
    currentSortDirection = 'desc';
    currentFilterColumn = '';
    currentFilterOp = 'equals';
    currentFilterValue = '';
    
    const [recordsResponse, schemaResponse] = await Promise.all([
        fetch(`/admin/tables/${table}?page=${currentPage}&limit=${pageSize}&sort_by=${currentSortColumn}&direction=${currentSortDirection}&filter=${currentFilterColumn}:${currentFilterOp}:${currentFilterValue}`, {
            headers: {
                'Authorization': `Bearer ${getCookie('access_token')}`
            }
        }),
        fetch(`/admin/table_schema/${table}`, {
            headers: {
                'Authorization': `Bearer ${getCookie('access_token')}`
            }
        })
    ]);
    const records = await recordsResponse.json();
    const schema = await schemaResponse.json();
    
    const foreignKeyData = await fetchForeignKeyData(schema);
    setupControls(schema);
    renderTable(table, records, schema, foreignKeyData);
}

async function fetchTableData(tableName) {
    console.log(`Fetching table data: ${tableName}`);
    const response = await fetch(`/admin/tables/${tableName}`);
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return await response.json();
}

async function fetchTables() {
    const response = await fetch('/admin/tables');
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return await response.json();
}

async function fetchForeignKeyData(schema) {
    const foreignKeyData = {};
    for (const field of schema.columns) {
        if (field.foreign_key) {
            const fkResponse = await fetch(`/admin/foreign_key/${field.foreign_key}`, {
                headers: {
                    'Authorization': `Bearer ${getCookie('access_token')}`
                }
            });
            const fkRecords = await fkResponse.json();
            console.log(`Foreign key data for ${field.name}:`, fkRecords);
            foreignKeyData[field.name] = fkRecords.reduce((map, item) => {
                map[item.id] = item.name;
                return map;
            }, {});
        }
    }
    return foreignKeyData;
}

function setupControls(schema) {
    const sortColumnSelect = document.getElementById('sortColumn');
    const filterColumnSelect = document.getElementById('filterColumn');
    sortColumnSelect.innerHTML = '';
    filterColumnSelect.innerHTML = '';

    schema.columns.forEach(column => {
        const sortOption = document.createElement('option');
        sortOption.value = column.name;
        sortOption.textContent = column.name;
        sortColumnSelect.appendChild(sortOption);

        const filterOption = document.createElement('option');
        filterOption.value = column.name;
        filterOption.textContent = column.name;
        filterColumnSelect.appendChild(filterOption);
    });

    document.getElementById('controls').style.display = 'block';
    document.getElementById('applyFiltersBtn').onclick = () => applyFilters(schema.table_name);
}

function renderTable(tableName, records, schema, foreignKeyData) {
    const tableContainer = document.getElementById('table-container');
    tableContainer.innerHTML = '';
    const table = document.createElement('table');
    table.className = 'table table-striped table-bordered';
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');

    if (records.length > 0) {
        Object.keys(records[0]).forEach(key => {
            const th = document.createElement('th');
            th.textContent = schema.columns.find(col => col.name === key).foreign_key ? `${key} (Name)` : key;
            th.style.cursor = 'pointer';
            th.onclick = () => sortTable(tableName, key);
            headerRow.appendChild(th);
        });
        const actionsTh = document.createElement('th');
        actionsTh.textContent = 'Actions';
        headerRow.appendChild(actionsTh);
    }

    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    records.forEach(record => {
        const row = document.createElement('tr');
        Object.entries(record).forEach(([key, value]) => {
            const td = document.createElement('td');
            td.textContent = foreignKeyData[key] ? foreignKeyData[key][value] : value;
            row.appendChild(td);
        });

        const actionsTd = document.createElement('td');
        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.className = 'btn btn-primary btn-sm mr-4';
        editBtn.onclick = () => openEditModal(tableName, record, schema, foreignKeyData);
        actionsTd.appendChild(editBtn);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.className = 'btn btn-danger btn-sm';
        deleteBtn.onclick = () => deleteRecord(tableName, record.id);
        actionsTd.appendChild(deleteBtn);

        row.appendChild(actionsTd);
        tbody.appendChild(row);
    });

    table.appendChild(tbody);
    tableContainer.appendChild(table);
    
    document.getElementById('addRowBtn').style.display = 'block';
    document.getElementById('addRowBtn').onclick = () => openAddModal(tableName, schema, foreignKeyData);

    document.getElementById('exportCsvBtn').style.display = 'block';
    document.getElementById('exportCsvBtn').onclick = () => exportTableToCsv(tableName);
}

function sortTable(tableName, column) {
    currentSortColumn = column;
    currentSortDirection = (currentSortDirection === 'asc') ? 'desc' : 'asc';
    console.log(`Sorting table ${tableName} by column ${column} in ${currentSortDirection} order`);
    loadTableWithSortingAndFiltering(tableName);
}

function applyFilters(tableName) {
    currentFilterColumn = document.getElementById('filterColumn').value;
    currentFilterOp = document.getElementById('filterOp').value;
    currentFilterValue = document.getElementById('filterValue').value;
    currentSortColumn = document.getElementById('sortColumn').value;
    currentSortDirection = document.getElementById('sortOrder').value;
    pageSize = parseInt(document.getElementById('pageSize').value, 10);
    currentPage = parseInt(document.getElementById('pageNumber').value, 10);
    console.log(`Applying filters to table ${tableName}`);
    loadTableWithSortingAndFiltering(tableName);
}

async function loadTableWithSortingAndFiltering(tableName) {
    console.log(`Loading table with sorting, filtering, and pagination: ${tableName}`);
    const filter = `${currentFilterColumn}:${currentFilterOp}:${currentFilterValue}`;
    const url = `/admin/tables/${tableName}?page=${currentPage}&limit=${pageSize}&sort_by=${currentSortColumn}&direction=${currentSortDirection}&filter=${filter}`;

    const [recordsResponse, schemaResponse] = await Promise.all([
        fetch(url, {
            headers: {
                'Authorization': `Bearer ${getCookie('access_token')}`
            }
        }),
        fetch(`/admin/table_schema/${tableName}`, {
            headers: {
                'Authorization': `Bearer ${getCookie('access_token')}`
            }
        })
    ]);
    const records = await recordsResponse.json();
    const schema = await schemaResponse.json();
    const foreignKeyData = await fetchForeignKeyData(schema);
    console.log(`Records loaded for ${tableName}:`, records);
    console.log(`Schema loaded for ${tableName}:`, schema);
    renderTable(tableName, records, schema, foreignKeyData);
}

async function openEditModal(tableName, record, schema, foreignKeyData) {
    const form = document.getElementById('edit-form');
    const modalLabel = document.getElementById('editModalLabel');
    modalLabel.textContent = `Edit ${tableName}`;
    form.innerHTML = '';
    console.log(`Schema for ${tableName}:`, schema);
    for (const field of schema.columns) {
        if (field.name === 'id') continue; // Skip the ID field
        const formGroup = document.createElement('div');
        formGroup.className = 'form-group';
        const label = document.createElement('label');
        label.textContent = field.name;
        if (field.not_null) label.style.color = 'red'; // Mark required fields
        formGroup.appendChild(label);
        if (field.foreign_key) {
            const select = document.createElement('select');
            select.className = 'form-control';
            select.name = field.name;
            foreignKeyData[field.name] && Object.entries(foreignKeyData[field.name]).forEach(([id, name]) => {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = name;
                if (id == record[field.name]) option.selected = true;
                select.appendChild(option);
            });
            formGroup.appendChild(select);
        } else {
            const input = document.createElement('input');
            input.type = 'text'; // Modify if schema provides type info
            input.className = 'form-control';
            input.name = field.name;
            input.value = record[field.name] || '';
            formGroup.appendChild(input);
        }
        form.appendChild(formGroup);
    }
    const submitButton = document.createElement('button');
    submitButton.type = 'button';
    submitButton.className = 'btn btn-success';
    submitButton.textContent = 'Save Changes';
    submitButton.onclick = () => submitEditForm(tableName, record.id);
    form.appendChild(submitButton);
    $('#editModal').modal('show');
}

async function submitEditForm(tableName, recordId) {
    const form = document.getElementById('edit-form');
    const formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });
    console.log(`Submitting data for ${tableName} with ID ${recordId}:`, data);
    const response = await fetch(`/admin/tables/${tableName}/${recordId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${getCookie('access_token')}`
        },
        body: JSON.stringify(data)
    });
    if (response.ok) {
        console.log('Changes saved successfully.');
        $('#editModal').modal('hide');
        loadTableWithSortingAndFiltering(tableName);
    } else {
        console.log('Error saving changes.');
        const errorText = await response.text();
        alert('Error saving changes: ' + errorText);
    }
}

async function openAddModal(tableName, schema, foreignKeyData) {
    const form = document.getElementById('add-form');
    const modalLabel = document.getElementById('addModalLabel');
    modalLabel.textContent = `Add Record to ${tableName}`;
    form.innerHTML = '';
    console.log(`Schema for ${tableName}:`, schema);
    for (const field of schema.columns) {
        if (field.name === 'id') continue; // Skip the ID field
        const formGroup = document.createElement('div');
        formGroup.className = 'form-group';
        const label = document.createElement('label');
        label.textContent = field.name;
        if (field.not_null) label.style.color = 'red'; // Mark required fields
        formGroup.appendChild(label);
        if (field.foreign_key) {
            const select = document.createElement('select');
            select.className = 'form-control';
            select.name = field.name;
            foreignKeyData[field.name] && Object.entries(foreignKeyData[field.name]).forEach(([id, name]) => {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = name;
                select.appendChild(option);
            });
            formGroup.appendChild(select);
        } else {
            const input = document.createElement('input');
            input.type = 'text'; // Modify if schema provides type info
            input.className = 'form-control';
            input.name = field.name;
            formGroup.appendChild(input);
        }
        form.appendChild(formGroup);
    }
    const submitButton = document.createElement('button');
    submitButton.type = 'button';
    submitButton.className = 'btn btn-success';
    submitButton.textContent = 'Add Record';
    submitButton.onclick = () => submitAddForm(tableName);
    form.appendChild(submitButton);
    $('#addModal').modal('show');
}

async function submitAddForm(tableName) {
    const form = document.getElementById('add-form');
    const formData = new FormData(form);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });
    console.log(`Submitting new record for ${tableName}:`, data);
    const response = await fetch(`/admin/tables/${tableName}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${getCookie('access_token')}`
        },
        body: JSON.stringify(data)
    });
    if (response.ok) {
        console.log('Record added successfully.');
        $('#addModal').modal('hide');
        loadTableWithSortingAndFiltering(tableName);
    } else {
        console.log('Error adding record.');
        const errorText = await response.text();
        alert('Error adding record: ' + errorText);
    }
}

async function exportTableToCsv(tableName) {
    const response = await fetch(`/admin/tables/${tableName}/csv`, {
        headers: {
            'Authorization': `Bearer ${getCookie('access_token')}`
        }
    });
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `${tableName}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
}

async function deleteRecord(tableName, recordId) {
    console.log(`Deleting record ${recordId} from ${tableName}`);
    const response = await fetch(`/admin/tables/${tableName}/${recordId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': `Bearer ${getCookie('access_token')}`
        }
    });
    if (response.ok) {
        console.log('Record deleted successfully.');
        loadTableWithSortingAndFiltering(tableName);
    } else {
        console.log('Error deleting record.');
        const errorText = await response.text();
        alert('Error deleting record: ' + errorText);
    }
}
