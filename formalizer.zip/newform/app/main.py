from fastapi import FastAPI, HTTPException, Request, Response, Depends, Form
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
import sqlite3
import json
import os
import csv
import io
import jwt
from jwt import PyJWTError
from datetime import datetime, timedelta

app = FastAPI()

# Load environment variables
PROJECT_DIR = os.getenv('PROJECT_DIR')
VENV_DIR = os.getenv('VENV_DIR')
DATABASE_PATH = os.getenv('DATABASE_PATH')
STATIC_DIR = os.getenv('STATIC_DIR')
SECRET_KEY = os.getenv('SECRET_KEY', 'mysecret')
ALGORITHM = 'HS256'
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Add session middleware
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

# Mount the static directory
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Allow CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_database_schema_as_json(db_path, table_name):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute(f"PRAGMA table_info({table_name});")
    columns = cursor.fetchall()
    schema = {
        "table_name": table_name,
        "columns": []
    }
    for col in columns:
        schema["columns"].append({
            "name": col[1],
            "type": col[2],
            "not_null": col[3] == 1,
            "default": col[4],
            "primary_key": col[5] == 1,
            "foreign_key": None  # Placeholder for foreign key
        })

    cursor.execute(f"PRAGMA foreign_key_list({table_name});")
    foreign_keys = cursor.fetchall()
    for fk in foreign_keys:
        for col in schema["columns"]:
            if col["name"] == fk[3]:
                col["foreign_key"] = fk[2]
                break

    conn.close()
    return schema

def authenticate_user(email: str, password: str):
    print(f"Authenticating user with email: {email} and password: {password}")
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM admins WHERE email = ? AND password = ?", (email, password))
    user = cursor.fetchone()
    conn.close()
    if user:
        print(f"Authentication successful for email: {email}")
        return {"email": email}
    print(f"Authentication failed for email: {email}")
    raise HTTPException(status_code=401, detail="Incorrect email or password")

def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return {"email": email}
    except PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return verify_token(token)

async def auth_dependency(request: Request):
    try:
        user = get_current_user(request)
        print(f"User {user['email']} is authenticated")
        return user
    except HTTPException:
        print("User not authenticated, redirecting to login")
        raise HTTPException(status_code=307, detail="Redirecting to login")

@app.middleware("http")
async def redirect_unauthorized_requests(request: Request, call_next):
    try:
        response = await call_next(request)
        if response.status_code == 307:
            return RedirectResponse(url="/login")
        return response
    except HTTPException as exc:
        if exc.status_code == 307:
            return RedirectResponse(url="/login")
        raise

@app.get("/")
async def index_page():
    with open(f"{STATIC_DIR}/index.html") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.get("/login")
async def login_page():
    print("Serving login page")
    with open(f"{STATIC_DIR}/login.html") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.post("/login")
async def login(request: Request, email: str = Form(...), password: str = Form(...)):
    print(f"Login attempt with email: {email}")
    try:
        user = authenticate_user(email, password)
        access_token = create_access_token(data={"sub": user["email"]}, expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
        response = RedirectResponse(url="/admin", status_code=302)
        response.set_cookie(key="access_token", value=access_token, httponly=True)
        print(f"User {email} successfully logged in")
        return response
    except HTTPException as e:
        print(f"Invalid login attempt for email: {email}")
        return RedirectResponse(url="/login", status_code=302)

@app.get("/admin", dependencies=[Depends(auth_dependency)])
async def get_admin_page(request: Request):
    with open(f"{STATIC_DIR}/admin.html") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.get("/admin/tables", dependencies=[Depends(auth_dependency)])
async def get_tables(request: Request):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [table[0] for table in cursor.fetchall() if table[0] != 'sqlite_sequence']
    conn.close()
    print(f"Tables available: {tables}")
    return tables

@app.get("/admin/tables/{table_name}", dependencies=[Depends(auth_dependency)])
async def get_table_data(
    request: Request,
    table_name: str, 
    page: int = 0, 
    limit: int = 25, 
    sort_by: str = None, 
    direction: str = 'asc', 
    filter: str = None,
):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    query = f"SELECT * FROM {table_name}"
    params = []

    if filter:
        column, op, value = filter.split(':')
        if value:  # Only add the filter if a value is provided
            if op == 'equals':
                query += f" WHERE {column} = ?"
            elif op == 'begins_with':
                query += f" WHERE {column} LIKE ?"
                value = f"{value}%"
            elif op == 'contains':
                query += f" WHERE {column} LIKE ?"
                value = f"%{value}%"
            params.append(value)

    if sort_by:
        direction = 'DESC' if direction == 'desc' else 'ASC'
        query += f" ORDER BY {sort_by} {direction}"

    query += f" LIMIT ? OFFSET ?"
    params.extend([limit, page * limit])

    cursor.execute(query, params)
    rows = cursor.fetchall()
    columns = [description[0] for description in cursor.description]
    conn.close()
    return [dict(zip(columns, row)) for row in rows]

@app.get("/admin/table_schema/{table_name}", dependencies=[Depends(auth_dependency)])
async def get_table_schema(request: Request, table_name: str):
    schema = get_database_schema_as_json(DATABASE_PATH, table_name)
    print(f"Schema for {table_name}: {schema}")
    return schema

@app.get("/admin/foreign_key/{table_name}", dependencies=[Depends(auth_dependency)])
async def get_foreign_key_data(request: Request, table_name: str):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute(f"SELECT id, name FROM {table_name};")
    rows = cursor.fetchall()
    conn.close()
    foreign_key_data = [{"id": row[0], "name": row[1]} for row in rows]
    print(f"Foreign key data for {table_name}: {foreign_key_data}")
    return foreign_key_data

@app.get("/admin/tables/{table_name}/csv", dependencies=[Depends(auth_dependency)])
async def get_table_csv(request: Request, table_name: str):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM {table_name};")
    rows = cursor.fetchall()
    columns = [description[0] for description in cursor.description]
    conn.close()
    
    if not rows:
        return Response(content="Table not found", status_code=404)
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns)
    writer.writeheader()
    for row in rows:
        writer.writerow(dict(zip(columns, row)))
    
    return Response(content=output.getvalue(), media_type='text/csv', headers={"Content-Disposition": f"attachment; filename={table_name}.csv"})

@app.put("/admin/tables/{table_name}/{record_id}", dependencies=[Depends(auth_dependency)])
async def update_table_record(
    request: Request,
    table_name: str, 
    record_id: int
):
    data = await request.json()
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        columns = ', '.join([f"{key} = ?" for key in data.keys()])
        values = list(data.values()) + [record_id]
        query = f"UPDATE {table_name} SET {columns} WHERE id = ?"
        cursor.execute(query, values)
        conn.commit()
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Record not found")
        print(f"Record updated successfully in {table_name}")
        return JSONResponse(content={"message": "Record updated successfully"})
    except sqlite3.Error as e:
        print(f"Error updating record in {table_name}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        conn.close()

@app.delete("/admin/tables/{table_name}/{record_id}", dependencies=[Depends(auth_dependency)])
async def delete_table_record(request: Request, table_name: str, record_id: int):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute(f"DELETE FROM {table_name} WHERE id = ?", (record_id,))
        conn.commit()
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Record not found")
        print(f"Record deleted successfully from {table_name}")
        return JSONResponse(content={"message": "Record deleted successfully"})
    except sqlite3.Error as e:
        print(f"Error deleting record from {table_name}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        conn.close()

@app.post("/admin/tables/{table_name}", dependencies=[Depends(auth_dependency)])
async def create_table_record(request: Request, table_name: str):
    data = await request.json()
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data.values()])
        values = list(data.values())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        cursor.execute(query, values)
        conn.commit()
        print(f"Record created successfully in {table_name}")
        return JSONResponse(content={"message": "Record created successfully", "id": cursor.lastrowid})
    except sqlite3.Error as e:
        print(f"Error creating record in {table_name}: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    finally:
        conn.close()

@app.exception_handler(HTTPException)
async def custom_http_exception_handler(request: Request, exc: HTTPException):
    print(f"HTTP Exception: {exc.detail}")
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
