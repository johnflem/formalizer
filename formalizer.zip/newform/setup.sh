#!/bin/bash

# Define the project directories
PROJECT_DIR=$(pwd)
VENV_DIR=$PROJECT_DIR/venv
DATABASE_PATH=$PROJECT_DIR/store.db
STATIC_DIR=$PROJECT_DIR/app/static

# Check if a database name is passed as an argument
if [ -z "$1" ]; then
  echo "No database name provided. Using default 'store.db'."
  DB_NAME="store.db"
else
  DB_NAME="$1"
  echo "Using provided database name: $DB_NAME"
fi


# Check if virtual environment exists
if [ ! -d "$VENV_DIR" ]; then
  echo "Creating virtual environment..."
  python3 -m venv $VENV_DIR
else
  echo "Virtual environment already exists."
fi

# Activate the virtual environment
source $VENV_DIR/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Set environment variables
export DATABASE_PATH=$DATABASE_PATH
export STATIC_DIR=$STATIC_DIR

# Inform user about environment variables
echo "Environment variables set:"
echo "DATABASE_PATH=$DATABASE_PATH"
echo "STATIC_DIR=$STATIC_DIR"

# Start the FastAPI application
echo "Starting FastAPI application..."
uvicorn app.main:app --reload
